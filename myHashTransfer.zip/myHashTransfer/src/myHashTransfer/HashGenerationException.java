package myHashTransfer;

public class HashGenerationException extends Exception {
	
	public HashGenerationException(String string,Exception ex) {
		// TODO Auto-generated constructor stub
	}

	public HashGenerationException() {
		// TODO Auto-generated constructor stub
	}

	public HashGenerationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HashGenerationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public HashGenerationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public HashGenerationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

package myHashTransfer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashTesterMain {
	
	private static String convertByteArrayToHexString(byte[] arrayBytes) {
	    StringBuffer stringBuffer = new StringBuffer();
	    for (int i = 0; i < arrayBytes.length; i++) {
	        stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16)
	                .substring(1));
	    }
	    return stringBuffer.toString();
	}
	
	private static String hashFile(File file) throws HashGenerationException{
	    try (FileInputStream inputStream = new FileInputStream(file)) {
	        MessageDigest digest = MessageDigest.getInstance("SHA-256");
	 
	        byte[] bytesBuffer = new byte[1024];
	        int bytesRead = -1;
	 
	        while ((bytesRead = inputStream.read(bytesBuffer)) != -1) {
	            digest.update(bytesBuffer, 0, bytesRead);
	        }
	 
	        byte[] hashedBytes = digest.digest();
	 
	        return convertByteArrayToHexString(hashedBytes);
	    } catch (NoSuchAlgorithmException | IOException ex) {
	        throw new HashGenerationException("Could not generate hash from file", ex);
	    }
	}
	
	
	public String generateSHA256(File file) throws HashGenerationException {
	    return hashFile(file);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashTesterMain hashTesterMain= new HashTesterMain();
		try {
            String filePath = args[0];
            System.out.println("File Path: " + filePath);
            File file = new File(filePath);
             
            String sha256Hash = hashTesterMain.generateSHA256(file);
            System.out.println("SHA-256 Hash: " + sha256Hash);         
 
        } catch (HashGenerationException ex) {
            ex.printStackTrace();
        }
	}

}
